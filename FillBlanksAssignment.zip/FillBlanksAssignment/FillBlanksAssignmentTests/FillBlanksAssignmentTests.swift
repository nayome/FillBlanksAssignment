//
//  FillBlanksAssignmentTests.swift
//  FillBlanksAssignmentTests
//
//  Created by NayomeDevapriyaAnga on 10/02/23.
//  Copyright © 2023 NayomeDevapriyaAnga. All rights reserved.
//

import XCTest
@testable import FillBlanksAssignment

class FillBlanksAssignmentTests: XCTestCase {
    
    var sut: WikiFillBlanksViewModel!
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        sut = WikiFillBlanksViewModel()
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        sut = nil
        super.tearDown()
    }
    
    func test_get_wikiContent() {
        sut.callFuncToGetWikiData { (receivedData) in
            self.sut.makeArrayFromString(receivedData: receivedData)
            XCTAssertEqual( self.sut.dataArray.count, 224 )

        }
        
        
        // XCTAssert reload closure triggered
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
}
