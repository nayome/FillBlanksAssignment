//
//  WikiFillBlanksViewModel.swift
//  FillBlanksAssignment
//
//  Created by NayomeDevapriyaAnga on 10/02/23.
//  Copyright © 2023 NayomeDevapriyaAnga. All rights reserved.
//

import Foundation

class WikiFillBlanksViewModel: NSObject {
    private var apiService: APIService!
     var dataArray = [String]()
     var hiddenWord = [String]()
     var hiddenWordLocation = [Int]()
    var shuffledHiddenWords = ["", "", "", "", "", "", "", "", "", ""]

    private(set) var wikiContent: String! {
        didSet {
            self.bindContentVMToController()
        }
    }
    
    var bindContentVMToController : (() -> ()) = {}

    override init() {
        super.init()
        self.apiService =  APIService()
        callFuncToGetWikiData { (receivedData) in
            if(receivedData != "Error") {
                self.makeArrayFromString(receivedData: receivedData)
            }
            
        }
    }
    
    func callFuncToGetWikiData(completion: @escaping (String) ->()) {
        self.apiService.apiToGetWikiContentFor(keyword: "Snake") { (receivedData) in
            if(receivedData != "") {
                self.wikiContent = receivedData
                completion(self.wikiContent)
            }
            else
            {
                completion("Error")
            }
        }

    }
    
    func makeArrayFromString(receivedData: String) {
         dataArray = receivedData.components(separatedBy: [" ","\n"])
        
        for i in 0..<10 {
            var randomIndex = Int(arc4random_uniform(UInt32(dataArray.count)))
            var randomWord = dataArray[randomIndex]
            
            
            while(randomWord.count < 8 || hiddenWordLocation.contains(randomIndex)){
                randomIndex = Int(arc4random_uniform(UInt32(dataArray.count)))
                randomWord = dataArray[randomIndex]
            }
            hiddenWord.append(randomWord)
            hiddenWordLocation.append(randomIndex)
            
            dataArray[randomIndex] = "(___\(i)___)"
        }
        shuffledHiddenWords = hiddenWord
    }

}
