//
//  ScoreTableViewCell.m
//  FillBlanksAssignment
//
//  Created by NayomeDevapriyaAnga on 13/02/23.
//  Copyright © 2023 NayomeDevapriyaAnga. All rights reserved.
//

#import "ScoreTableViewCell.h"

@implementation ScoreTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
