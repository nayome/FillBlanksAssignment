//
//  ScoreTableViewCell.h
//  FillBlanksAssignment
//
//  Created by NayomeDevapriyaAnga on 13/02/23.
//  Copyright © 2023 NayomeDevapriyaAnga. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScoreTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *userGuessLabel;
@property (weak, nonatomic) IBOutlet UILabel *rightAnswerLabel;
@property (weak, nonatomic) IBOutlet UILabel *numberIndicatorLabel;

@end
