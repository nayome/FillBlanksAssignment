//
//  APIService.swift
//  FillBlanksAssignment
//
//  Created by NayomeDevapriyaAnga on 10/02/23.
//  Copyright © 2023 NayomeDevapriyaAnga. All rights reserved.
//

import Foundation

class APIService :  NSObject {
    

    func apiToGetWikiContentFor(keyword: String, completion: @escaping (String) ->()) {
        let url = URL(string: "\(baseURL)\("Snake")\(settingsURL)")
        
        if let usableUrl = url {
            let request = URLRequest(url: usableUrl)
            let task = URLSession.shared.dataTask(with: request, completionHandler: { (data, response, error) in
                DispatchQueue.main.async {
                    if let data = data {
                        do {
                                let model = try JSONDecoder().decode(WikiStruct.self, from: data)
                                if let keys = model.query.pages?.keys {
                                    for key in keys {
                                        if let pageData = model.query.pages![key] {
                                            let wikiContent = pageData.extract ?? ""
                                            print(wikiContent)
                                            completion(wikiContent)
                                        } 
                                    }
                                }
                            }catch {
                                print("exception")
                                completion("")
                            }
                        }
                    }
                })
                task.resume()
            }
        }

}
