//
//  Constants.swift
//  WiKiFill
//
//  Created by NayomeDevapriyaAnga on 07/02/23.
//  Copyright © 2023 NayomeDevapriyaAnga. All rights reserved.
//

import Foundation
let baseURL = "https://en.wikipedia.org/w/api.php?action=query&prop=extracts&exsentences=10&format=json&titles="
let settingsURL = "&explaintext=1"
let documents = ["Snake","food","Pet_door","Cricket","Sachin_Tendulkar"]




var score = 0
var correctAnswer = [String]()
var userAnswer = [String]()
