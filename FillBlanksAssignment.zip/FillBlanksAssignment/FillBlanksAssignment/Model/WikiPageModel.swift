//
//  WikiPageModel.swift
//  WiKiFill
//
//  Created by NayomeDevapriyaAnga on 07/02/23.
//  Copyright © 2023 NayomeDevapriyaAnga. All rights reserved.
//

import Foundation
typealias Pages = [String]



struct WikiStruct: Codable {
    var query : QueryStruct
    var batchComplete: String?
}

struct QueryStruct : Codable{
    var pages: [String:PageStruct]?
}

struct PageStruct: Codable {
    var pageId: Int?
    var ns: Int?
    var title: String?
    let extract: String?
}
