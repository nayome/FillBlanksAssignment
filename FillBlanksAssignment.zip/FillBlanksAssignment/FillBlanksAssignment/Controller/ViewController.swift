//
//  ViewController.swift
//  FillBlanksAssignment
//
//  Created by NayomeDevapriyaAnga on 10/02/23.
//  Copyright © 2023 NayomeDevapriyaAnga. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextViewDelegate {
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var submitButton: UIButton!
    
    var tappedWord: String = ""
    
    var buttons = [UIButton]()
    var userGuess = ["", "", "", "", "", "", "", "", "", ""]
    var previousSelectedWord = ["", "", "", "", "", "", "", "", "", ""]
    var buttonPressed = -1
    private var wikiViewModel: WikiFillBlanksViewModel!
  
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let text = NSMutableAttributedString(string: " ")
        textView.attributedText = text
        textView.font = UIFont.systemFont(ofSize: 25.0)

        callToVMForUIUpdates()
        
        pickerView.isHidden = true
    }
    
    
    
    @IBAction func submitClicked(_ sender: Any) {
        print(userGuess)
        for i in 0..<10 {
            if(self.wikiViewModel.shuffledHiddenWords[i] == userGuess[i]){
                score += 1
            }
        }
        correctAnswer = self.wikiViewModel.shuffledHiddenWords
        userAnswer = userGuess
        performSegue(withIdentifier: "toScoreScreen", sender: self)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func callToVMForUIUpdates() {
        FBProgressView.shared.showProgressView(view)
        self.wikiViewModel = WikiFillBlanksViewModel()
        
        self.wikiViewModel.bindContentVMToController = {
            FBProgressView.shared.hideProgressView()
            DispatchQueue.main.async {
                self.updateTextView()
                self.pickerView.reloadAllComponents()
                self.addButtonOverText()
            }
        }
    }
    
    
    func updateTextView()  {
        var text = ""
        for index in 0..<self.wikiViewModel.dataArray.count {
            text += "\(self.wikiViewModel.dataArray[index]) "
        }
        let str = NSMutableAttributedString(string: text)
        textView.attributedText = str
        textView.font = UIFont.systemFont(ofSize: 25.0)

    }
    
    func addButtonOverText(){
        for i in 0..<10 {
            let copyText = textView.text as NSString
            let range = copyText.range(of: "(___\(i)___)", options: .literal, range: NSMakeRange(0, copyText.length))
            textView.layoutManager.ensureLayout(for: textView.textContainer)
            let start = textView.position(from: textView.beginningOfDocument, offset: range.location)!
            let end = textView.position(from: start, offset: range.length)!
            let tRange = textView.textRange(from: start, to: end)
            let rect = textView.firstRect(for: tRange!)
            
            let button = UIButton(frame: CGRect(x: rect.minX+5, y: rect.minY, width: 85, height: 25))
            button.backgroundColor = .white
            button.alpha = 1.0
            button.setTitle("", for: .normal)
            button.tag = i
            button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
            self.textView.addSubview(button)
            buttons.append(button)
        }
    }


    @objc func buttonAction(sender: UIButton!) {
        buttonPressed = sender.tag
        pickerView.isHidden = false
    }

    func replaceSelectedWordIntext(selectedWord: String){
        self.wikiViewModel.dataArray[self.wikiViewModel.hiddenWordLocation[buttonPressed]] = userGuess[buttonPressed]
        var text = ""
        for index in 0..<self.wikiViewModel.dataArray.count {
            text += "\(self.wikiViewModel.dataArray[index]) "
        }
        textView.text = text
        pickerView.isHidden = true
        buttons[buttonPressed].isHidden = true
        changeButtonLocationForOtherWords(changedIndex: buttonPressed)
        
        if let str = textView.text {
            let text = NSMutableAttributedString(string: str)
            var searchRange = str.startIndex..<str.endIndex
            for userSlectedWord in userGuess {
                if (userSlectedWord != "") {
                    while let range = str.range(of: userSlectedWord, options: NSString.CompareOptions.caseInsensitive, range: searchRange) {
                        text.addAttribute(NSAttributedStringKey.foregroundColor, value: UIColor.blue, range: NSRange(range, in: str))
                        searchRange = range.upperBound..<searchRange.upperBound
                    }
                }
            }
            textView.attributedText = text
            textView.font = UIFont.systemFont(ofSize: 25.0)
        }
    }
    
    func changeButtonLocationForOtherWords(changedIndex:Int){
        for i in 0..<10 {
            if(i != changedIndex){
                let copyText = textView.text as NSString
                let range = copyText.range(of: "(___\(i)___)", options: .literal, range: NSMakeRange(0, copyText.length))
                textView.layoutManager.ensureLayout(for: textView.textContainer)
                if (range.location < 50000){
                    let start = textView.position(from: textView.beginningOfDocument, offset: range.location)!
                    let end = textView.position(from: start, offset: range.length)!
                    let tRange = textView.textRange(from: start, to: end)
                    let rect = textView.firstRect(for: tRange!)
                    
                    buttons[i].frame = CGRect(x: rect.minX+5, y: rect.minY, width: 85, height: 25)
                }
                
            }
        }
    }

}

extension ViewController: UIPickerViewDataSource, UIPickerViewDelegate {
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.wikiViewModel.shuffledHiddenWords.count
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return "\(self.wikiViewModel.shuffledHiddenWords[row])"
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        userGuess[buttonPressed] = self.wikiViewModel.shuffledHiddenWords[row]
        replaceSelectedWordIntext(selectedWord: self.wikiViewModel.shuffledHiddenWords[row])
    }
}


